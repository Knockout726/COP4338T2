#include <stdio.h>
#include <string.h>
#define MAX_LEN 1000
int check(char input[]);
extern char opening_symbol[];
extern char closing_symbol[];
void pair(char list[]);