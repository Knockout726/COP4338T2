#ifndef STACK_H
#define STACK_H

#include <stdbool.h>

bool is_empty();

#endif